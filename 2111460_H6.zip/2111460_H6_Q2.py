#!/usr/bin/env python
# coding: utf-8

# In[60]:


class node(object):
    def __init__(self, name = None, frequency = None):
        self._name = name
        self._frequency = frequency
        self._left = None
        self._right = None
    def is_leaf(self):
        if self._left == None and self._right == None:
            return True
        else:
            return False


# In[61]:


def Huffman(frequency, n): #构建哈夫曼树
    leaf = [node(i[0], i[1]) for i in frequency]
    while len(leaf) != 1: #当leaf中还有节点时循环继续
        leaf.sort(key = lambda node:node._frequency)
        n = n + 1
        temp = node(n - 1, leaf[0]._frequency + leaf[1]._frequency) #temp节点的值为最小的两个数相加
        temp._left = leaf.pop(0) #新建节点的左孩子
        temp._right = leaf.pop(0) #新建节点的右孩子
        leaf.append(temp)
    root = leaf[0]
    return root


# In[62]:


def code(root, get_code, buffer): #遍历得到编码
    if root._left:
        get_code.append(0)
        get_code = code(root._left, get_code, buffer)
    if root._right:
        get_code.append(1)
        get_code = code(root._right, get_code, buffer)
    if root.is_leaf() is True:
        buffer[root._name] = get_code
        if get_code[-1] == 1 and len(get_code) >= 2:
            return get_code[0:len(get_code) - 2]
        else:
            return get_code[0:len(get_code) - 1]
    return get_code


# In[66]:


if __name__ == "__main__":
    n = eval(input())
    x = list(map(int, input().split(" ")))
    frequency = [[]for i in range(n)]
    for i in range(n):
        frequency[i] = [i, x[i]]
    root = Huffman(frequency, n)
    get_code = []
    buffer = [[]for i in range(n)] #记录哈夫曼编码
    flag = True
    code(root, get_code, buffer)
    length = 0 #计算编码总长度
    num = 0 #频率的和
    for i in range(n):
        length += len(buffer[i])*frequency[i][1]
        num += frequency[i][1]
    avg_length = length / num
    print("%.2f"%avg_length)

