#!/usr/bin/env python
# coding: utf-8

# In[34]:


def distance(p1, p2): #d^2 = (x1-x2)^2+(y1-y2)^2
    return (p1[0]-p2[0])**2 + (p1[1]-p2[1])**2
def closest_pair(points):
    if len(points) <= 1: #点的个数小于等于1，return
        return None, float('inf')
    else:
        sorted_points = sorted(points, key=lambda p: p[0]) #按照横坐标排序
        mid = len(points) // 2   #把points分为个数相等的两部分
        left_points = sorted_points[:mid]
        right_points = sorted_points[mid:]
        #分别找出左边和右边的最小距离和相应的点
        left_pair, left_dist = closest_pair(left_points)
        right_pair, right_dist = closest_pair(right_points)
        #更新最小距离和点
        if left_dist < right_dist:
            pair, closest_dist = left_pair, left_dist
        else:
            pair, closest_dist = right_pair, right_dist
        #找到中间点的横坐标和距离中间点横坐标距离为closest_dist的点
        mid_x = sorted_points[mid][0]
        strip_points = [p for p in sorted_points if abs(p[0] - mid_x) < closest_dist]
        strip_sorted_points = sorted(strip_points, key = lambda p: p[1]) #按纵坐标排序
        #找到相对于当前坐标点最近的7个点比较当前距离和最短距离，更小则更新
        for i, p1 in enumerate(strip_sorted_points):
            for p2 in strip_sorted_points[i+1:i+8]:
                d = distance(p1, p2)
                if d < closest_dist:
                    pair, closest_dist = (p1, p2), d
        return pair, closest_dist


# In[36]:


if __name__=="__main__":
    n = eval(input())
    points = [[]for i in range(n)]
    for i in range(n):
        points[i] = list(map(float, input().split(" ")))
    pair, closest_dist = closest_pair(points)
    print("%.2f"%closest_dist)


# In[ ]:




