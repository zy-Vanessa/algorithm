#!/usr/bin/env python
# coding: utf-8

# In[2]:


def count_inversions(arr): #求inversion的个数
    if len(arr) <= 1:
        return arr, 0
    else:
        mid = len(arr) // 2
        left, inv_left = count_inversions(arr[:mid])
        right, inv_right = count_inversions(arr[mid:])
        merged, inv_merge = merge(left, right)
        return merged, inv_left + inv_right + inv_merge


# In[3]:


def merge(left, right):
    merged = []
    inv_count = 0
    i = 0
    j = 0
    while i < len(left) and j < len(right):
        if left[i] <= right[j]: #左边的值小于等于右边的值
            merged.append(left[i])
            i += 1
        else: #右边的值小于左边的值
            merged.append(right[j])
            j += 1
            inv_count += len(left) - i #inversion的个数加上len(left)-i
    merged += left[i:] #加上多出的部分
    merged += right[j:]
    return merged, inv_count


# In[4]:


if __name__=="__main__":
    n = eval(input())
    arr = list(map(int, input().split(" ")))
    merged, inv_count = count_inversions(arr)
    print(inv_count)


# In[ ]:




