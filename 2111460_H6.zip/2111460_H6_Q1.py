#!/usr/bin/env python
# coding: utf-8

# In[14]:


def find_shortest_path(distance, adjacent, n):#找到最短路径
    min = float("inf")
    node1, node2 = 0, 0
    for i in range(n):
        for j in range(len(distance[i])):
            if distance[i][j] < min:
                min = distance[i][j]
                node1 = i
                node2 = adjacent[i][j]
                p, q = i, j
    distance[p][q] = float("inf") #添加后让这条边的值变为正无穷
    return [node1, node2, min] #返回值为最短路径的两个节点和路径的长度


# In[22]:


def Kruskal(adjacent, distance, n):
    [node1, node2, min] = find_shortest_path(distance, adjacent, n)
    s = set() #集合中存放节点
    length = min  #最短路径总长度
    s.add(node1)
    s.add(node2)
    while len(s) != n:
        [node1, node2, min] = find_shortest_path(distance, adjacent, n)
        #新加入的节点不能构成环
        if node1 not in s:
            if node2 not in s:
                s.add(node1)
                s.add(node2)
            else:
                s.add(node1)
        else:
            if node2 not in s:
                s.add(node2)
            else:
                continue
        length += min
    print(length)
            


# In[23]:


if __name__ == "__main__":
    n, e = map(int, input().split(' '))
    adjacent = [[]for j in range(n+1)]
    distance = [[]for j in range(n+1)]
    min, j = 1000,0 #记录最短的一条边和出发节点
    for i in range(e):
        p, q, l = map(int, input().split(' '))
        adjacent[p].append(q)
        distance[p].append(l)
    Kruskal(adjacent, distance, n)

