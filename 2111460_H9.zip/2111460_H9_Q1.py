#!/usr/bin/env python
# coding: utf-8

# In[6]:


def backtrack(number, path, result):#回溯法
    # 如果路径长度等于数组长度，将路径添加到结果列表
    if len(path) == len(number):
        result.append(path[:])
        return
    
    # 对于每个数字，如果它不在路径中，就将它添加到路径中并继续回溯
    for i in number:
        if i not in path:
            path.append(i)
            backtrack(number, path, result)
            path.pop() #遍历全部数字

def permute(n):
    number = [i+1 for i in range(n)]#number中是从1到n的整数
    result = []
    backtrack(number, [], result)
    return result


# In[10]:


if __name__=="__main__":
    n = eval(input())
    print(permute(n))


# In[ ]:




