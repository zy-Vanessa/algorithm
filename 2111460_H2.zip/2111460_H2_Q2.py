#!/usr/bin/env python
# coding: utf-8

# In[10]:


def merge(array_A,array_B):
    array = []
    i, j = 0, 0
    while i < len(array_A) and j < len(array_B):
        if array_A[i] < array_B[j]:
            array.append(array_A[i])
            i += 1
        else:
            array.append(array_B[j])
            j += 1
    #剩余数组中多余的元素
    array += array_A[i:]
    array += array_B[j:]
    return array


# In[12]:


if __name__=="__main__":
    print("Please input array A:")
    n = input()
    array_A = [int(j) for j in n.split()]
    print("Please input array B:")
    n = input()
    array_B = [int(j) for j in n.split()]
    print(merge(array_A,array_B))


# In[ ]:




