#!/usr/bin/env python
# coding: utf-8

# In[27]:


print("Please input array:")
x = input()#间隔空格输入
array = list(map(int, x.split(' ')))
print("Please input targeted number:")
T = eval(input())
n = len(array)


# In[2]:


#O(n^3) 两层遍历
import time
def add_to_T1(array , T):
    for i in range(n):
        for j in range(i + 1 , n):
            for k in range(j + 1 , n):
                if array[i] + array[j] + array[k] == T:
                    print(array[i],array[j],array[k])


# In[28]:


t = time.perf_counter()
add_to_T1(array , T)
print(f'coast:{time.perf_counter() - t:.8f}s')


# In[4]:


def binary_search(array,x):
    left = 0
    right = len(array) - 1
    while left <= right:
        mid = (right + left) // 2    #取中间元素索引
        if array[mid] == x:
            return True
        elif x > array[mid]:
            left = mid + 1     #到array[mid + 1 ...right]里查找
        else: 
            right = mid - 1    #到array[left ...mid - 1]里查找
    return False    #未找到元素


# In[17]:


#O(n^2logn) 确定前两个值，另一个值用二分查找
import time
def add_to_T2(array , T):
    for i in range(n):
        for j in range(i+1,n):
            array_left = array[j+1:n]
            if binary_search(array_left , T - (array[i] + array[j])) is True:
                print(array[i],array[j],T-array[i]-array[j])


# In[29]:


t = time.perf_counter()
add_to_T2(array , T)
print(f'coast:{time.perf_counter() - t:.8f}s')


# In[21]:


#O(n^2) 利用三个指针，第一个指针固定，当前值小于T则第二个指针向后移，大于T则第三个指针向前移
import time
def add_to_T3(array ,  T):
    for i in range(n):
        j = i+1
        k = n-1
        while j < k:
            if array[i]+array[j]+array[k] < T:
                j += 1
                continue
            elif array[i]+array[j]+array[k] > T:
                k -= 1
                continue
            else:
                print(array[i],array[j],array[k])
                j += 1


# In[30]:


t = time.perf_counter()
add_to_T3(array , T)
print(f'coast:{time.perf_counter() - t:.8f}s')


# In[ ]:




