#!/usr/bin/env python
# coding: utf-8

# In[7]:


def binary_search(array,x):
    left = 0
    right = len(array) - 1
    while left <= right:
        mid = (right + left) // 2    #取中间元素索引
        if array[mid] == x:
            return mid
        elif x > array[mid]:
            left = mid + 1     #到array[mid + 1 ...right]里查找
        else: 
            right = mid - 1    #到array[left ...mid - 1]里查找
    return -1    #未找到元素


# In[11]:


if __name__ == "__main__":
    n = input()
    array = [int(j) for j in n.split()]
    x = eval(input())
    print(binary_search(array,x)) #第一个数索引为0 第n个数索引为n-1


# In[ ]:




