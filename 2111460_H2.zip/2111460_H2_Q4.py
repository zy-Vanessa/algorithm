#!/usr/bin/env python
# coding: utf-8

# In[14]:


import math
def shortest_distance(x):
    min = math.sqrt(math.pow(x[1][0] - x[0][0], 2) + math.pow(x[1][1] - x[0][1], 2))
    result = [x[0],x[1]]
    for i in range(n):
        for j in range(i+1,n):
            d = math.sqrt(math.pow(x[j][0] - x[i][0], 2) + math.pow(x[j][1] - x[i][1], 2))
            if d < min:
                min = d
                result = [x[i],x[j]]
    print(result)


# In[15]:


str = input()
#输入示例  {(1.2,1.3),(1,2),(2.4,1.9),(2.1,2.2)}
point = []
k,m,p,point_x,point_y = 0,0,0,0,0
for i in range(len(str)): #输入字符串后提取数据存入列表
    if str[i] == '(':
        k = i
    elif str[i] == ',':
        m = i
    elif str[i] == ')':
        p = i
    if k!=0 and m!=0 and m > k:
        x = ''
        for j in range(k+1,m):
            x += str[j]
        point_x = float(x)
        k=0
    elif m!=0 and p!=0 and p > m:
        y = ''
        for j in range(m+1,p):
            y += str[j]
        point_y = float(y)
        p,m=0,0
    if point_x!=0 and point_y!=0:
        point += [point_x,point_y]
        point_x,point_y = 0,0
n = int(len(point)/2)
_point = [[0,0]for i in range(n)]
for i in range(n):
    _point[i] = [point[i*2],point[i*2+1]]
    
#计算最短距离
shortest_distance(_point)


# In[ ]:




