#!/usr/bin/env python
# coding: utf-8

# In[13]:


import random

def is_prime(num):
    if num < 2:
        return False
    for i in range(2, int(num**0.5) + 1):
        if num % i == 0:
            return False
    return True

def find_prime(m):
    primes = [num for num in range(m) if is_prime(num)]
    return random.choice(primes)

def find_string(X, Y):
    n = len(X)
    m = len(Y)
    
    #取M=2*n*n
    M = 2*n*n

    # 从小于M的素数集中随机选择一个素数p
    p = find_prime(M)

    # 计算W_p = 2^m (mod p)
    W_p = pow(2, m, p)

    # 计算I_p(Y)
    I_p_Y = calculate_hash(Y, p)

    # 计算I_p(X_1)
    I_p_X = calculate_hash(X[:m], p)

    j = 1
    while j <= n - m + 1:
        if I_p_X == I_p_Y:
            return j - 1

        # 计算I_p(X_{j+1})
        I_p_X = ((2 * I_p_X - ord(X[j-1]) * W_p + ord(X[j+m-1])) % p)

        j += 1

    return -1 #Y不在X中

def calculate_hash(string, p):
    # 计算模p的哈希值
    hash_value = 0
    for char in string:
        hash_value = (hash_value * 2 + ord(char)) % p
    return hash_value


# In[15]:


if __name__=='__main__':
    X = input()
    Y = input()
    result = find_string(X, Y)
    print(result) 


# In[ ]:




