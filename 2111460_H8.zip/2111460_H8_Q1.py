#!/usr/bin/env python
# coding: utf-8

# In[21]:


def brute_force(A, B, m):#穷举法
    longest = []
    for i in range(2 ** m): #2^m种可能，依次遍历
        sub = []
        for j in range(m):
            if i & ( 1 << j ):#转换成二进制：如果i为7，因为7=111，所以把后三位加入到sub中
                sub.append(A[j])
        if len(sub) > len(longest) and is_sub(sub, B):#更新longest
            longest = sub
    return longest

def is_sub(sub, B):#判断sub是不是B的子序列
    j = 0
    for i in range(len(sub)):
        while j < len(B) and sub[i] != B[j]:#判断B的当前字母是不是和sub对应，不是则j加一
            j += 1
        if j == len(B):#j等于len(B)时说明已经遍历完B，但是仍然没有找到与sub对应的字母，说明sub不是B的子序列
            return False
        j += 1
    return True


# In[27]:


def dynamic_programming(A, B, m):#动态规划法
    dp = [[0] * (m+1) for _ in range(m+1)] #(m+1)*(m+1)的矩阵
    for i in range(1, m+1):
        for j in range(1, m+1):
            if A[i-1] == B[j-1]:
                dp[i][j] = dp[i-1][j-1] + 1
            else:
                dp[i][j] = max(dp[i-1][j], dp[i][j-1])
    #倒推找到最长公共子序列
    i = j = m
    longest = []
    while i > 0 and j > 0:
        if A[i-1] == B[j-1]:
            longest.append(A[i-1])
            i -= 1
            j -= 1
        elif dp[i-1][j] > dp[i][j-1]:
            i -= 1
        else:
            j -= 1
    longest.reverse()
    return longest


# In[5]:


import random
import string

def generate_random_string(m): # 随机生成只包含小写字母的字符串
    return ''.join(random.choices(string.ascii_lowercase , k=m))


# In[50]:


if __name__=="__main__":
    m = eval(input())
    A = generate_random_string(m)
    print(A)
    B = generate_random_string(m)
    print(B)


# In[51]:


import time
#测试穷举法时间性能（十次取平均）
total = 0
for i in range(10):
    t = time.perf_counter()
    result = brute_force(A, B, m)
    total += float("%.8f"%(time.perf_counter() - t))
    print(f'{(time.perf_counter() - t):.8f}s')
    
print(f'brute_force_cost:{total/10:.8f}s')
print("brute_force_result:",''.join(result))


# In[52]:


#测试动态规划法时间性能（十次取平均）
total = 0
for i in range(10):
    t = time.perf_counter()
    result = dynamic_programming(A, B, m)
    total += float("%.8f"%(time.perf_counter() - t))
    print(f'{(time.perf_counter() - t):.8f}s')
    
print(f'dynamic_cost:{total/10:.8f}s')
print("dynamic_result:",''.join(result))


# In[ ]:




