#!/usr/bin/env python
# coding: utf-8

# In[6]:


file = open(r'hpc.in','r')
file_contents = file.readlines()
na,nb = map(int,file_contents[0].split(' '))
p = int(file_contents[1])
    
# 重定向输入输出流
#sys.stdin = open(r'C:\Users\15478\Desktop\hpc.in', 'r')
#sys.stdout = open('hpc.out', 'w')


ta, tb, ka, kb = [0] * (p + 2), [0] * (p + 2), [0] * (p + 2), [0] * (p + 2)

for i in range(2, p + 2):
    ta[i-1], tb[i-1], ka[i-1], kb[i-1] = map(int, file_contents[i].split(' '))

f1 = [[[0] * 65 for i in range(65)] for j in range(25)]
f2 = [[[0] * 65 for i in range(65)] for j in range(25)]

def DP1():
    for a in range(1, p + 1):
        F = [[[0] * 65 for i in range(65)] for j in range(2)]
        for i in range(na + 1):
            for j in range(nb + 1):
                F[1][i][j] = F[0][i][j] = float('inf')
        F[0][0][0] = F[1][0][0] = 0
        for i in range(na + 1):
            for j in range(nb + 1):
                for k in range(1, i + 1):
                    F[0][i][j] = min(F[0][i][j], F[1][i - k][j] + ka[a] * k * k + ta[a])
                for k in range(1, j + 1):
                    F[1][i][j] = min(F[1][i][j], F[0][i][j - k] + kb[a] * k * k + tb[a])
                f1[a][i][j] = min(F[0][i][j], F[1][i][j])

def DP2():
    for i in range(na + 1):
        for j in range(nb + 1):
            f2[1][i][j] = f1[1][i][j]
    for a in range(2, p + 1):
        for i in range(na + 1):
            for j in range(nb + 1):
                f2[a][i][j] = float('inf')
                for k in range(i + 1):
                    for l in range(j + 1):
                        f2[a][i][j] = min(f2[a][i][j], max(f2[a - 1][k][l], f1[a][i - k][j - l]))

DP1()
DP2()

fout = open('hpc.out','w')
fout.write(str(f2[p][na][nb]))
fout.close()

