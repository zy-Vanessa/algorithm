#!/usr/bin/env python
# coding: utf-8

# In[40]:


account = input()
length = len(account)
if account[0] == '-' and length == 2: #e.g."-5"去掉最后一位直接变为0    
    print(0)
elif account[0] == '-':#只有负数用到这个present才能增大资产
    sum_money = account
    account_delete1 = account[0:length-1] #去掉最后一位
    sum_money = account_delete1 if int(account_delete1) > int(sum_money) else sum_money 
    account_delete2 = account[0:length-2]+account[length-1] #去掉倒数第二位
    sum_money = account_delete2 if int(account_delete2) > int(sum_money) else sum_money
    print(int(sum_money))
else: #正数不做任何处理
    print(account)


# In[ ]:




