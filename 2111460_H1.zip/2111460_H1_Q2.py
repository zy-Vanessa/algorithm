#!/usr/bin/env python
# coding: utf-8

# In[18]:


n,m,a,b=map(int,input().split())
sum = n * a #计算方案所需钱数,有更低价格的方案时更新为更小值
for i in range(n // m + 1):
    sum_money = i * b + (n - m * i) * a
    if sum_money < sum :
        sum = sum_money
print(sum)


# In[ ]:




