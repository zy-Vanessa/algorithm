#!/usr/bin/env python
# coding: utf-8

# In[1]:


def turn_to_array(array):#把输入的字符串转换成字符数组
    for i in range(n):
        str = input()
        j = 0
        array[i][j] = str[0]
        j += 1 
        for k in range (len(str)):
            if str[k]!='>':continue
            else:
                array[i][j] = str[k-1]
                j += 1
        array[i][j] = str[len(str)-1]


# In[2]:


def man_number(array,k,man_name):#男人在女人满意度中的排名，返回值越小越靠前
    for i in range(n):
        if man_name == woman_array[k][i+1]:
            return i
        else:
            continue


# In[6]:


def stable_matching(man_array,woman_array):
    is_man_free = [True]*n #判断男人是不是单身
    is_woman_free = [True]*n #判断女人是不是单身
    is_man_proposed = [[False for i in range(n)]for j in range(n)] #判断男人是否向对应的女人求婚
    match = [[-1,-1]]*n #最终有n对情侣
    i = 0
    while i>=0 and i<n:#遍历所有男人
        man = man_array[i][0] #man为当前待匹配的男人
        if is_man_free[i] is True:
            for j in range(n):
                woman = man_array[i][j+1] #按心仪程度遍历所有女人
                if is_man_free[i] == False: break
                k = 0
                for pos in range(n):
                    if woman == woman_array[pos][0]:#在woman_array数组中找到当前的女人
                        k = pos
                        break
                if is_woman_free[k] == True and is_man_proposed[i][j] == False: #判断女人当前是否单身和男人是否已经向该女人求婚
                    match[i] = [man,woman]
                    is_man_free[i]=False  #更改状态
                    is_woman_free[k]=False
                    is_man_proposed[i][j]=True
                elif is_woman_free[k] == False and is_man_proposed[i][j] == False:
                    compare_man = -1 #已经和当前的女人配对的男人
                    m = 0
                    for mat in range(n): #找到第几个男人和当前女人配对，记录为m
                        if match[mat][1] == woman:
                            compare_man = match[mat][0]
                            m = mat
                    if man_number(woman_array,k,compare_man)>man_number(woman_array,k,man):#比较心仪程度 man的排名靠前则重新选择
                        match[i]=[man,woman]
                        match[m]=[-1,-1]
                        is_man_free[i]=False
                        is_man_proposed[i][j]=True
                        is_man_free[m]=True
                        i = m-1 #从第m个男人继续遍历，防止有人没有配对
                        break
                    else:
                        is_man_proposed[i][j]=True
        i+=1
    for i in range(n):
        print("("+match[i][0]+","+match[i][1]+")")
                                


# In[8]:


if __name__ == '__main__':
    n = eval(input())
    man_array =  [[0 for col in range(n+1)] for row in range(n)]
    woman_array = [[0 for col in range(n+1)] for row in range(n)]
    turn_to_array(man_array)
    turn_to_array(woman_array)
    stable_matching(man_array,woman_array)


# In[ ]:




