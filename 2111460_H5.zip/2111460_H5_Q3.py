#!/usr/bin/env python
# coding: utf-8

# In[1]:


def mini(a,b):
    if a < b:
        return a
    else:
        return b


# In[11]:


def Prim(adjacent, distance, node1, node2, m, n):
    result = [] #记录经过的路径
    result.append(node1)
    result.append(node2)
    dist = [-1]*(n+1) #记录长度
    length = m #最小生成树的长度
    for i in range(len(adjacent[node1])):
        dist[adjacent[node1][i]] = distance[node1][i]
    temp = node2
    while len(result) != n:
        for i in range(len(adjacent[temp])):
            if dist[adjacent[temp][i]] == -1: #dist中值为-1表示还没有记录路径
                dist[adjacent[temp][i]] = distance[temp][i] 
            else: #选择最短路径
                dist[adjacent[temp][i]] = mini(dist[adjacent[temp][i]], distance[temp][i])
        for i in range(n+1):
            if dist[i] != -1 and i not in result:
                min = dist[i]
                j = i
                break
        for i in range(n+1):
            if dist[i] != -1 and i not in result:
                if dist[i] < min:
                    min = dist[i]
                    j = i
        result.append(j)
        temp = j
        length += dist[j]
    print(length)


# In[13]:


if __name__ == "__main__":
    n, e = map(int, input().split(' '))
    adjacent = [[]for j in range(n+1)]
    distance = [[]for j in range(n+1)]
    min, j = 1000,0 #记录最短的一条边和出发节点
    for i in range(e):
        p, q, l = map(int, input().split(' '))
        adjacent[p].append(q)
        adjacent[q].append(p)
        distance[p].append(l)
        distance[q].append(l)
        if l < min:
            min = l
            node1 = p
            node2 = q
    Prim(adjacent, distance, node1, node2, min, n)


# In[ ]:




