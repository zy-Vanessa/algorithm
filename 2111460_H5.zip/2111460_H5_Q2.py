#!/usr/bin/env python
# coding: utf-8

# In[1]:


def mini(a,b):
    if a < b:
        return a
    else:
        return b


# In[2]:


def Dijkstra(adjacent, distance, source, n):
    temp = source
    result = [] #记录结果
    result.append(source)
    dist = [-1]*(n+1) #记录长度
    dist[source] = 0
    while len(result) != n:
        for i in range(len(adjacent[temp])):
            if dist[adjacent[temp][i]] == -1: #dist中值为-1表示还没有记录路径
                dist[adjacent[temp][i]] = dist[temp] + distance[temp][i] 
            else: #选择最短路径
                dist[adjacent[temp][i]] = mini(dist[adjacent[temp][i]], dist[temp] + distance[temp][i])
        for i in range(n+1):
            if dist[i] != -1 and dist[i] != 0 and i not in result:
                min = dist[i]
                j = i
                break
        for i in range(n+1):
            if dist[i] != -1 and dist[i] != 0 and i not in result:
                if dist[i] < min:
                    min = dist[i]
                    j = i
        if j not in result:
            result.append(j)
            temp = j
    for i in range(1,n+1):
        print(dist[i], end = ' ')


# In[3]:


if __name__ == "__main__":
    n, e, s = map(int, input().split(' '))
    adjacent = [[]for j in range(n+1)]
    distance = [[]for j in range(n+1)]
    for i in range(e):
        p, q, l = map(int, input().split(' '))
        adjacent[p].append(q)
        distance[p].append(l)
    Dijkstra(adjacent, distance, s, n)


# In[ ]:




