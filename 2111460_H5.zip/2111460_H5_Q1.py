#!/usr/bin/env python
# coding: utf-8

# In[1]:


def is_exist(cache, x): #判断元素是否在cache中存在
    for i in range(len(cache)):
        if x == cache[i]:
            return True
    return False


# In[40]:


def position(cache, request, i): #i表示request中的当前位置，计算cache中哪个元素在request中出现的最晚，替换掉最晚出现的元素
    s = set() #用集合记录前n-1个元素
    for j in range(i+1, len(request)):
        if request[j] in cache:
            s.add(request[j])  #把当前cache中存在的元素添加到s中
        if len(s) == len(cache) - 1: #如果集合中有n-1个数，跳出循环，找到最晚出现的元素
            break
    if len(s) < len(cache) - 1: #s中的元素个数不满k-1，向前数
        for j in range(i - 1, -1 , -1):
            if request[j] in cache:
                s.add(request[j])
            if len(s) == len(cache) - 1: #如果集合中有n-1个数，跳出循环，找到最晚出现的元素
                break
    s = list(s)
    for j in range(len(cache)):
        if cache[j] not in s:
            print(cache[j], end = ' ')
            return j   #返回替换掉cache中的第几个元素


# In[18]:


def optimal_caching(cache, request, k, n):
    q = len(request)
    for i in range(q):
        if is_exist(cache, request[i]) is True:
            continue
        elif n < k: #cache中的元素个数不满k
            cache.append(request[i])
            n += 1
        else: #FF
            j = position(cache, request, i)
            cache[j] = request[i]


# In[41]:


if __name__ == "__main__":
    k,n,s = map(int, input().split(' '))
    cache = list(map(int, input().split(' ')))
    request = list(map(int, input().split(' ')))
    optimal_caching(cache, request, k, n)


# In[ ]:




