#!/usr/bin/env python
# coding: utf-8

# In[41]:


import heapq

# 定义节点类
class Node:
    def __init__(self, teacher_assignments, cost, level):
        self.teacher_assignments = teacher_assignments
        self.cost = cost
        self.level = level
        
    def __lt__(self, other):
        return self.cost < other.cost

def arange_class(time, n_teachers, n_courses):
    # 初始化队列和已访问节点列表
    queue = []
    visited = []

    # 初始化根节点，使用最小堆来保存节点，每次选择下界最小的节点进行扩展
    root_node = Node([-1] * n_courses, 0, 0)#没有老师教授的课程都设置为-1
    heapq.heappush(queue, root_node)
    visited.append(root_node.teacher_assignments)

    # 初始化最优解和最优解的备课时间
    best_solution = None
    best_cost = float('inf')

    # 分支限界搜索
    while queue:
        # 从队列中弹出限界最小的节点
        curr_node = heapq.heappop(queue)

        # 如果当前节点的限界大于当前最优解，则跳过该节点
        if curr_node.cost >= best_cost:
            continue

        # 扩展当前节点的子节点
        for i in range(n_courses):
            # 如果课程i已经分配给一个老师，则跳过该课程
            if curr_node.teacher_assignments[i] != -1:
                continue

            # 扩展子节点
            for j in range(n_teachers):
                # 如果老师j已经分配了一门课，则跳过该老师
                if j in curr_node.teacher_assignments:
                    continue

                # 计算新节点的备课时间和限界
                new_teacher_assignments = curr_node.teacher_assignments.copy()#把父节点的教师教课信息传递给子节点
                new_teacher_assignments[i] = j
                new_cost = curr_node.cost + times[j][i]
                new_level = curr_node.level + 1

                # 创建新节点并加入队列和已访问节点列表
                new_node = Node(new_teacher_assignments, new_cost, new_level)
                if new_teacher_assignments not in visited:
                    heapq.heappush(queue, new_node)
                    visited.append(new_teacher_assignments)

                    # 检查新节点是否为叶节点，如果是，则更新最优解和最优解的备课时间
                    if new_node.level == n_courses and new_node.cost < best_cost:
                        best_solution = new_node.teacher_assignments
                        best_cost = new_node.cost

    # 打印最优解和最优解的备课时间
    print(f"最优解：{best_solution}")
    for i in range(n_courses):
        print("第",best_solution[i]+1,"位老师教授第",i+1,"门课程，备课时间为:",time[best_solution[i]][i])
    print(f"最小备课时间：{best_cost}")


# In[42]:


if __name__=='__main__':
    # 输入数据
    time = [[2, 10, 9, 7],
             [15, 4, 14, 8],
             [13, 14, 16, 11],
             [4, 15, 13, 9]]
    n_teachers = 4
    n_courses = 4
    arange_class(time, n_teachers, n_courses)

