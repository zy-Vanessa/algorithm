#!/usr/bin/env python
# coding: utf-8

# In[16]:


def bfs(_list,n,layer): 
    queue = []     #定义队列
    flag = set()   #建立一个集合，集合就是用来判断该元素是不是已经出现过
    i = 0
    queue.append(i)  #将i节点放入
    flag.add(i)
    while (len(queue)>0) : #当队列里还有东西时
        ver =  queue.pop(0) #取出队头元素
        notes = _list[ver] #查看list里面的值,对应的邻接点
        for j in notes:#遍历邻接点
            if j not in flag: #如果该邻接点还没出现过
                queue.append(j) #存入queue
                flag.add(j) #存入集合
                layer[j] = layer[ver] + 1 #j的层数等于ver的层数加一


# In[21]:


#判断是不是二分图，判断通过bfs算法算出的同一层中的节点中是否相连。相连则不是二分图。
def bipartiteness(layer,n,_list):
    for i in range(n):
        for j in range(i+1,n):
            if layer[i] == layer[j]:
                if is_connected(i,j,_list) is True:
                    return False
    return True


# In[20]:


def is_connected(a,b,_list):#判断节点是否相连
    for i in range(len(_list[a])):
        if _list[a][i] == b:
            return True
    return False


# In[ ]:


n, m = map(int, input().split()) #输入n,m
adjacency_list = [[]for j in range(n)] #邻接链表
for j in range(m):
    p,q = map(int, input().split()) #把输入的边对应的信息加入到链表中
    adjacency_list[p].append(q) 
    adjacency_list[q].append(p)
layer = [[]for i in range(n)]
layer[0] = 0
bfs(adjacency_list,n,layer) #bfs
if bipartiteness(layer,n,adjacency_list) is True:
    print("Yes")
else:
    print("No")

