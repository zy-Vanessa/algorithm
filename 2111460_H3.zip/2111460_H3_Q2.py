#!/usr/bin/env python
# coding: utf-8

# In[18]:


def bfs(_list,i): 
    queue = []     #定义队列
    flag = set()   #建立一个集合，用来判断该元素是不是已经出现过
    queue.append(i)  #将i节点放入
    flag.add(i)
    while (len(queue)>0) : #当队列里还有东西时
        ver =  queue.pop(0) #取出队头元素
        notes = _list[ver] #查看list里面的值,对应的邻接点
        for j in notes:#遍历邻接点
            if j not in flag: #如果该邻接点还没出现过
                queue.append(j) #存入queue
                flag.add(j) #存入集合
        print(ver,end = ' ')
    print(' ')


# In[15]:


def dfs(_list,i): 
    stack = []    #定义栈
    flag = set()    #建立一个集合，用来判断该元素是不是已经出现过
    stack.append(i)  #将i节点放入
    flag.add(i)
    while (len(stack)>0) : #当栈里还有东西时
        ver =  stack.pop() #取出栈顶元素
        notes = _list[ver] #查看list里面的值,对应的邻接点
        for j in notes: #遍历邻接点
            if j not in flag:  #如果该邻接点还没出现过
                stack.append(j)  #存入stack
                flag.add(j)   #存入集合
        print(ver,end = ' ')


# In[21]:


n, m, i= map(int, input().split()) #输入n,m,i
adjacency_list = [[]for j in range(n)] #邻接链表
for j in range(m):
    p,q = map(int, input().split()) #把输入的边对应的信息加入到链表中
    adjacency_list[p].append(q) 
    adjacency_list[q].append(p)
for j in range(n):
    adjacency_list[j].sort()
bfs(adjacency_list,i) #bfs
for j in range(n):
    adjacency_list[j].sort(reverse = True)
dfs(adjacency_list,i) #dfs

