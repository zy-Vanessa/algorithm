#!/usr/bin/env python
# coding: utf-8

# In[3]:


def topological_order(_list,degree,n):
    seen = set() #用集合记录已经排序过的节点
    i = 0
    while i < n:
        if len(seen) == n: #当集合中包含所有节点 return
            return
        flag = True #判断度有没有变化
        if degree[i] == 0: #度为0的进集合
            if i not in seen:
                seen.add(i)
                print(i,end = ' ')
                for j in range(len(_list[i])):
                    degree[_list[i][j]] -= 1 #与度为0的节点相邻的节点的度减一
                    flag = False
        if flag == True:
            i += 1
        else:
            i = 0


# In[ ]:


n, m = map(int,input().split())
adjacency_list = [[]for j in range(n)] #邻接链表
degree = [0]*n #度
for i in range(m):
    p,q = map(int, input().split()) #把输入的边对应的信息加入到链表中
    adjacency_list[p].append(q) 
    degree[q] += 1
topological_order(adjacency_list,degree,n)

