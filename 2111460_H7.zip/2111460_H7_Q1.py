#!/usr/bin/env python
# coding: utf-8

# In[2]:


def dynamic(values, weights, capacity, n):#动态规划
    dp = [[0 for _ in range(capacity+1)] for _ in range(n+1)]
    
    for i in range(1, n+1):#前i个物品
        for j in range(1, capacity+1):
            dp[i][j] = dp[i-1][j]
            if weights[i-1] <= j:
                dp[i][j] = max(dp[i][j], dp[i-1][j-weights[i-1]] + values[i-1])
    
    max_value = dp[n][capacity]
    return max_value


# In[3]:


if __name__=="__main__":
    V, n = map(int, input().split(' '))
    v, w=[], []
    for i in range(n):
        weight, value = map(int, input().split(' '))
        v.append(value)
        w.append(weight)
    print(dynamic(v, w, V, n))


# In[ ]:




