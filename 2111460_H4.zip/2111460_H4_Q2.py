#!/usr/bin/env python
# coding: utf-8

# In[1]:


#冒泡排序 用来排序开始时间
def bubble_sort(time, n):
    for i in range(n):
        for j in range(0, n-i-1):
            if time[j][0] > time[j+1][0]: #比较开始时间
                time[j], time[j+1] = time[j+1], time[j] #时间交换
            elif time[j][0] == time[j+1][0]: #开始时间相同，比较结束时间
                if time[j][1] > time[j+1][1]:
                    time[j], time[j+1] = time[j+1], time[j]


# In[23]:


def earliest_start_time_first(time, n):
    number = 1 #number of classrooms
    cr = [] #记录当前教室的最后一门课程的结束时间
    cr.append(time[0][1])
    for i in range(1, n): #遍历课程
        flag = False #判断已有教室是否能排开当前课程
        for j in range(number): #遍历教室
            if time[i][0] >= cr[j]: #比较待添加课程的起始时间和教室中最后一个课程的结束时间
                cr[j] = time[i][1]
                flag = True
                break
        if flag == False:
            cr.append(time[i][1]) #不满足if语句则新开一个教室
            number += 1 
    print(number)


# In[27]:


if __name__ == "__main__":
    n = eval(input()) #事件总数
    time = [[0,0]for i in range(n)] #输入开始时间，结束时间
    for i in range(n):
        time[i] = list(map(int, input().split(' ')))
    bubble_sort(time, n)
    earliest_start_time_first(time, n)


# In[ ]:




