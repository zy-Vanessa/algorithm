#!/usr/bin/env python
# coding: utf-8

# In[3]:


#冒泡排序 用来排序ddl时间
def bubble_sort(time, n):
    for i in range(n):
        for j in range(0, n-i-1):
            if time[j][1] > time[j+1][1]: #比较ddl
                time[j], time[j+1] = time[j+1], time[j] #时间交换
            elif time[j][1] == time[j+1][1]: #ddl相同，比较持续时间
                if time[j][0] > time[j+1][0]:
                    time[j], time[j+1] = time[j+1], time[j]


# In[5]:


def earliest_deadline_first(time, n):
    lateness = 0 
    current_time = 0
    for i in range(n):
        current_time += time[i][0]
        if current_time > time[i][1]: #如果超出ddl
            lateness += current_time - time[i][1]
    print(lateness)


# In[6]:


if __name__ == "__main__":
    n = eval(input()) #事件总数
    time = [[0,0]for i in range(n)] #输入processing time,deadline time
    for i in range(n):
        time[i] = list(map(int, input().split(' ')))
    bubble_sort(time, n)
    earliest_deadline_first(time, n)


# In[ ]:




