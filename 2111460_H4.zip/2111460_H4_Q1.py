#!/usr/bin/env python
# coding: utf-8

# In[34]:


#冒泡排序 用来排序结束时间
def bubble_sort(time, n):
    for i in range(n):
        for j in range(0, n-i-1):
            if time[j][1] > time[j+1][1]: #比较结束时间
                time[j], time[j+1] = time[j+1], time[j] #时间交换
            elif time[j][1] == time[j+1][1]: #结束时间相同，比较开始时间
                if time[j][0] > time[j+1][0]:
                    time[j], time[j+1] = time[j+1], time[j]


# In[35]:


def earliest_finish_time_first(time, n):
    finish_time = time[0][1] #事实记录并更改结束时间
    number = 1 #number of compatible jobs
    for i in range(n):
        if time[i][0] < finish_time:
            continue
        else:
            finish_time = time[i][1] #更改finish_time
            number += 1
    print(number)


# In[37]:


if __name__ == "__main__":
    n = eval(input()) #事件总数
    time = [[0,0]for i in range(n)] #输入开始时间，结束时间
    for i in range(n):
        time[i] = list(map(int, input().split(' ')))
    bubble_sort(time, n)
    earliest_finish_time_first(time, n)


# In[ ]:




